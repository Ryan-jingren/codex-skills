param([string]$Destination)
$ErrorActionPreference = 'Stop'
if (-not $Destination) {
    $codexBase = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $HOME '.codex' }
    $Destination = Join-Path $codexBase 'skills'
}
$source = Join-Path $PSScriptRoot 'skills'
$names = @('codex-ppt','origin-publication-figure','research-paper-writing','visio-image-rebuilder')
foreach ($name in $names) {
    if (-not (Test-Path -LiteralPath (Join-Path $source "$name\SKILL.md"))) { throw "Missing skill: $name" }
}
New-Item -ItemType Directory -Path $Destination -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
foreach ($name in $names) {
    $target = Join-Path $Destination $name
    if (Test-Path -LiteralPath $target) {
        $oldBackup = Join-Path (Split-Path $Destination -Parent) "skill-backups\$stamp\$name"
        New-Item -ItemType Directory -Path (Split-Path $oldBackup -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $target -Destination $oldBackup -Recurse
    }
    New-Item -ItemType Directory -Path $target -Force | Out-Null
    Get-ChildItem -LiteralPath (Join-Path $source $name) -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse -Force
    }
    Write-Host "Installed: $name"
}
Write-Host 'Restart Codex to refresh skills. External applications and MCP connections must be configured separately.'

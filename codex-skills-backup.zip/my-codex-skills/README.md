# Personal Codex skills backup

Contains four locally installed skills. This repository is public, as requested by its owner.

## Restore on Windows

Download and extract the repository ZIP from GitHub, then double-click install.cmd.
Alternatively, run: powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
The process-only execution-policy option does not change the saved Windows policy.

Default destination: CODEX_HOME\skills, or %USERPROFILE%\.codex\skills.
For another skill location, run install.ps1 -Destination <path>.
Existing same-name skills are copied to a timestamped skill-backups folder before files are updated.
Restart Codex after installation.

This restores skill instructions, scripts and assets only. It does not install Origin,
Visio, Python packages, MCP servers, plugins, or API credentials. Check dependencies
on the new computer. Codex account sign-in alone does not download this repository.

Backup snapshot: 2026-10-12. To back up later edits, refresh the skill folders and push a new commit.

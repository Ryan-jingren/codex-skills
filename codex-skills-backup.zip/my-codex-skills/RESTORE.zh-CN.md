# 新电脑恢复指南

## 备份内容

- codex-ppt：学术演示文稿工作流、脚本及风格模板。
- origin-publication-figure：Origin 科研绘图规范与工具使用说明。
- research-paper-writing：学术写作规范、章节参考和示例。
- visio-image-rebuilder：Visio 图形重建工作流与 PowerShell 脚本。
- install.ps1 / install.cmd：Windows 安装入口。
- manifest.json：技能文件 SHA-256 校验清单。

## 恢复步骤

1. 在新电脑登录 GitHub，下载本仓库 ZIP 并完整解压。
2. 双击 install.cmd，或让 Codex 检查后运行 install.ps1。
3. 默认安装到当前 Windows 用户的 .codex/skills；如果设置了 CODEX_HOME，则使用该目录下的 skills。
4. 重启 Codex，确认四个技能出现在可用技能列表中。
5. 若当前客户端使用其他技能路径，运行 install.ps1 -Destination 对应目录。

如果已有同名技能，安装前会复制到技能目录旁的 skill-backups 时间戳目录。

## 软件与工具依赖

- 学术写作：通常只需技能文本。
- PPT：按 codex-ppt/requirements.txt 配置 Python 依赖；图片生成工具或 API 服务按需连接。API 密钥应在新电脑单独配置。
- Origin：需要安装并授权 Origin/OriginPro，并重新配置本地 originlab MCP 服务。本仓库包含技能，不包含该服务器实现。
- Visio：需要安装并授权 Microsoft Visio。本仓库包含 COM 辅助脚本；如需 visio MCP 工具，另行安装和连接服务器。
- Codex 内置与插件提供的技能由客户端或插件管理；在新电脑恢复相应插件，不复制缓存目录。

本仓库不包含登录凭据、API 密钥、聊天数据库或电脑系统设置。
侧边栏分区和项目配置不由这些技能文件恢复。学术资料及成果也应另外备份。

## 后续更新

这是一个时间点的备份。修改本机技能后，应重新备份并上传新提交，GitHub 不会自动监视本机技能目录。

可以在新电脑向 Codex 发送：
“从我的 GitHub 技能备份仓库下载，检查文件后运行安装脚本，验证四个技能是否已安装，并告诉我缺少哪些外部依赖。”
